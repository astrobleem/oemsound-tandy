from pathlib import Path
import ctypes,subprocess,json,hashlib,struct
r=Path(__file__).resolve().parent;s=r/'SOURCE';lib=r/'synth-test.so'
subprocess.run(['gcc','-x','c','-std=c89','-pedantic','-Wall','-Wextra','-Werror','-shared','-fPIC','-o',str(lib),str(s/'SYNTH.C')],check=True)
f=ctypes.CDLL(str(lib));tests=0
for p in range(11):
 for vel in range(1,128):
  f.SynthInit()
  a=f.SynthStart(0,vel,p,0);assert 0<=a<=15
  assert f.SynthProfile(0)==p and f.SynthAge(0)==0
  for age in range(1,33):
   a=f.SynthAdvance(0,1);assert 0<=a<=15
   assert f.SynthAge(0)==min(age,15)
   assert a==f.SynthStart(1,vel,p,min(age,15))
   tests+=1
  f.SynthStop(0);assert f.SynthAdvance(0,65535)==15
  assert f.SynthStart(0,vel,p,65535)==f.SynthStart(1,vel,p,15)
  f.SynthStart(0,vel,p,0);f.SynthAdvance(0,5)
  f.SynthStart(1,127,1,0);assert f.SynthAge(0)==5
  f.SynthStart(0,vel,p,0);assert f.SynthAge(0)==0
  tests+=5
for p in range(8,11):
 assert f.SynthStart(0,127,p,15)==15
for p in range(8):
 assert f.SynthStart(0,110,p,15)<15
f.SynthInit()
for p,v in [(11,50),(0,0),(0,128)]:assert f.SynthStart(0,v,p,0)==15
res={'status':'PASS','portable_core_assertion_groups':tests,'profile_count':11,'voice_count':4,'step_hz':18.2065,'max_envelope_port_writes_per_update':4,'tests':['all profiles and velocities','retrigger restarts','unrelated voice remains unchanged','age saturates','large catch-up single pass','inactive voice mute','percussion expires','tonal sustain floor','invalid inputs safely muted']}
(r/'SYNTH-TESTS.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
