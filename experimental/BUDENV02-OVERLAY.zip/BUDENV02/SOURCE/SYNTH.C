/* BUDENV01: newly authored envelopes, no borrowed instrument data.
   One step per unchanged BIOS tick (~54.925 ms). No timer or port I/O.
   Curves are attenuation OFFSETS, relative to the score's velocity.
   Offset 15 ends a percussion envelope; notes still retain their identity.
   Tonal curves settle rather than extend note durations at note-off. */
#include "SYNTH.H"
typedef struct {
    unsigned char active, age, preset, base;
} VOICE;
static VOICE voices[4];
static signed char curves[SYNTH_PRESETS][SYNTH_STEPS] = {
    /* rounded verse lead: small bloom, then a warm settling tail */
    { 1, 0, 0, 1, 2, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
    /* forward chorus lead, keeping a body beneath the attack */
    {-2,-1, 0, 1, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 },
    /* short solo pick, then a sustained pitched center */
    {-2, 0, 2, 3, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 },
    /* bridge lead: a two-step swell, long-held body */
    { 3, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
    /* round bass, preserving the score's original register */
    {-1, 0, 1, 2, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
    /* clipped root/fifth guitar accompaniment */
    {-2, 0, 2, 4, 6, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 },
    /* sustained written harmony: no false repeated attack */
    { 2, 1, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 },
    /* guitar response brought forward in a written melody gap */
    {-3,-1, 1, 2, 3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 },
    /* periodic-noise kick; fixed chip clock, no tone slot stolen */
    {-1, 2, 6,15,15,15,15,15,15,15,15,15,15,15,15,15 },
    /* white-noise snare */
    {-2, 1, 5,15,15,15,15,15,15,15,15,15,15,15,15,15 },
    /* white-noise closed hat */
    { 0, 5,15,15,15,15,15,15,15,15,15,15,15,15,15,15 }
};
void SynthInit(void)
{
    unsigned i;
    for(i=0;i<4;i++)voices[i].active=0;
}
unsigned SynthAtten(unsigned voice)
{
    VOICE *v;int offset,atten;
    if(voice>=4)return 15;
    v=voices+voice;if(!v->active)return 15;
    offset=curves[v->preset][v->age];
    if(offset==15)return 15;
    atten=(int)v->base+offset;
    if(atten<0)atten=0;
    if(atten>15)atten=15;
    return (unsigned)atten;
}
unsigned SynthStart(unsigned voice,unsigned velocity,unsigned preset,
                    unsigned age)
{
    VOICE *v;
    if(voice>=4)return 15;
    v=voices+voice;
    if(!velocity||velocity>127||preset>=SYNTH_PRESETS){
        v->active=0;return 15;
    }
    v->base=(unsigned char)(14-((velocity-1)*14)/126);
    v->preset=(unsigned char)preset;
    v->age=(unsigned char)(age<16?age:15);v->active=1;
    return SynthAtten(voice);
}
void SynthStop(unsigned voice)
{
    if(voice<4)voices[voice].active=0;
}
unsigned SynthAdvance(unsigned voice,unsigned delta)
{
    VOICE *v;unsigned age;
    if(voice>=4)return 15;
    v=voices+voice;if(!v->active)return 15;
    if(delta>15)delta=15;
    age=(unsigned)v->age+delta;
    v->age=(unsigned char)(age<16?age:15);
    return SynthAtten(voice);
}
unsigned SynthAge(unsigned voice)
{
    return voice<4?voices[voice].age:0;
}
unsigned SynthProfile(unsigned voice)
{
    return voice<4?voices[voice].preset:0;
}
