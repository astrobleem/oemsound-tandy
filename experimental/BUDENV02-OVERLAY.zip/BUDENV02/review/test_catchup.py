from pathlib import Path
import subprocess, ctypes, struct, re, random, json, hashlib
R=Path(__file__).resolve().parent.parent
S=R/'SOURCE'; OUT=R/'review'
src=(S/'DOSPLAY.C').read_text()
functions=src[src.index('static unsigned instrumentFor('):src.index('static int captionMusic(')]
pre=r'''
#include <string.h>
#include "SYNTH.H"
#include "INSTRMAP.H"
#include "PERIODS.H"
#define U32 unsigned long
#define U8 unsigned char
#define DAY_TICKS 0x1800b0UL
typedef struct { U32 when; U8 note[4],velocity[4],retrigger; } STATE;
static STATE current,nextState,seed;
static int seedValid,nextValid,seedRestoring,mode=1;
static U32 synthTick,synthPasses,synthWrites,synthSkippedTicks;
static U32 voiceOrigin[4],seedOrigin[4],restoreAt;
static unsigned synthMaxWrites,synthMaxGap,instrumentIndex,profileStarts[SYNTH_PRESETS],seedProfiles[4];
static U8 volume[4]={15,15,15,15};
static U32 playStart,playEnd=600000UL,lastService,prerolled,maxGap,applied,skipped,totalLate,maxLate;
static STATE testEvents[10000];
static unsigned testCount,testIndex,testWrites;
static U32 testTick;
static U32 ClockTick(void) { return testTick; }
static U32 since(U32 first,U32 last) { return last>=first?last-first:DAY_TICKS-first+last; }
static void output(unsigned b) { (void)b;testWrites++; }
static int fetchEvent(void) {
    if(testIndex==testCount)nextValid=0;
    else {nextState=testEvents[testIndex++];nextValid=1;}
    return 1;
}
'''
post=r'''
void TestReset(STATE *events,unsigned count) {
 unsigned i;
 memset(&current,0,sizeof(current));memset(&nextState,0,sizeof(nextState));memset(&seed,0,sizeof(seed));
 seedValid=nextValid=seedRestoring=0;mode=1;
 synthTick=synthPasses=synthWrites=synthSkippedTicks=0;
 memset(voiceOrigin,0,sizeof(voiceOrigin));memset(seedOrigin,0,sizeof(seedOrigin));
 restoreAt=0;synthMaxWrites=synthMaxGap=instrumentIndex=0;
 memset(profileStarts,0,sizeof(profileStarts));memset(seedProfiles,0,sizeof(seedProfiles));
 for(i=0;i<4;i++)volume[i]=15;
 playStart=lastService=prerolled=maxGap=applied=skipped=totalLate=maxLate=0;
 testCount=count;testIndex=testWrites=0;testTick=0;
 for(i=0;i<count;i++)testEvents[i]=events[i];
 SynthInit();fetchEvent();
}
unsigned TestService(U32 now,U32 tick) {testTick=tick;testWrites=0;return (unsigned)musicService(now);}
unsigned TestPrime(U32 when,U32 tick) {
 unsigned result;playStart=when;testTick=synthTick=tick;
 result=(unsigned)primeMusic();
 if(seedValid){restoreAt=playStart;seedRestoring=1;soundState(&seed);seedRestoring=0;applied++;}
 return result;
}
unsigned TestNote(unsigned v) { return current.note[v]; }
unsigned TestVelocity(unsigned v) { return current.velocity[v]; }
U32 TestOrigin(unsigned v) { return voiceOrigin[v]; }
unsigned TestVolume(unsigned v) { return volume[v]; }
unsigned TestWrites(void) { return testWrites; }
unsigned TestMaxWrites(void) { return synthMaxWrites; }
U32 TestSkipped(void) { return skipped; }
unsigned TestStarts(unsigned v) { return profileStarts[v]; }
'''
(OUT/'catchup_harness.c').write_text(pre+functions+post)
cmd=['gcc','-x','c','-std=c89','-pedantic','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-shared','-fPIC','-I'+str(S),str(OUT/'catchup_harness.c'),str(S/'SYNTH.C'),'-o',str(OUT/'catchup_harness.so')]
subprocess.run(cmd,check=True,capture_output=True,text=True)
f=ctypes.CDLL(str(OUT/'catchup_harness.so'))
class State(ctypes.Structure):
 _fields_=[('when',ctypes.c_ulong),('note',ctypes.c_ubyte*4),('velocity',ctypes.c_ubyte*4),('retrigger',ctypes.c_ubyte)]
f.TestReset.argtypes=[ctypes.POINTER(State),ctypes.c_uint]
f.TestService.argtypes=f.TestPrime.argtypes=[ctypes.c_ulong,ctypes.c_ulong]
f.TestOrigin.restype=f.TestSkipped.restype=ctypes.c_ulong
rows=[(t,tuple(x[:4]),tuple(x[4:8]),x[8]) for t,*x in struct.iter_unpack('<I10B',(R/'WEEZER.WZM').read_bytes()[20:])]
maprows=[tuple(map(int,m)) for m in re.findall(r'\{(\d+)UL, (\d+), (\d+), (\d+)\}',(S/'INSTRMAP.H').read_text())]
curves=[list(map(int,re.findall(r'-?\d+',m))) for m in re.findall(r'\{([^{}]+)\}',(S/'SYNTH.C').read_text().split('static signed char curves')[1].split('void SynthInit')[0])]
assert len(curves)==11
checks=0

def profile(v,n,t):
 if v==3:return 8 if n in (35,36) else 9 if n in (38,40) else 10
 return next(m for m in reversed(maprows) if m[0]<=t)[v+1]
def attenuation(vel,p,age):
 o=curves[p][age]
 return 15 if o==15 else max(0,min(15,14-((vel-1)*14)//126+o))
def reset(rr):
 a=(State*len(rr))(*(State(t,(ctypes.c_ubyte*4)(*ns),(ctypes.c_ubyte*4)(*vs),mask) for t,ns,vs,mask in rr));f.TestReset(a,len(rr))
def run(rr,times):
 global checks
 reset(rr);idx=0;ns=[0]*4;vs=[0]*4;orig=[0]*4;pr=[0]*4;age=[0]*4;tick=0;expected_skipped=0
 for now in times:
  newtick=int(now*1000//54925)
  age=[min(15,a+newtick-tick) for a in age];tick=newtick
  dirty=[False]*4;count=0
  while idx<len(rr) and rr[idx][0]<=now:
   t,nn,vv,mask=rr[idx]
   for v in range(4):
    if ns[v]!=nn[v] or vs[v]!=vv[v] or mask&(1<<v):
     dirty[v]=True;orig[v]=t;pr[v]=profile(v,nn[v],t)
   ns=list(nn);vs=list(vv);idx+=1;count+=1
  expected_skipped+=max(0,count-1)
  for v in range(4):
   if dirty[v]:age[v]=min(15,(now-orig[v])*1000//54925) if count>1 else 0
  assert f.TestService(now,tick)==1
  assert f.TestSkipped()==expected_skipped
  assert f.TestMaxWrites()<=4
  # Emitted work is at most 4 envelope changes plus 4 tone transactions.
  assert f.TestWrites()<=20
  for v in range(4):
   assert f.TestNote(v)==ns[v] and f.TestVelocity(v)==vs[v],(now,v,'state')
   assert f.TestVolume(v)==(attenuation(vs[v],pr[v],age[v]) if ns[v] else 15),(now,v,'volume',f.TestVolume(v),pr[v],age[v])
   if ns[v]:
    assert f.SynthAge(v)==age[v],(now,v,'age',f.SynthAge(v),age[v])
    assert f.SynthProfile(v)==pr[v],(now,v,'profile',f.SynthProfile(v),pr[v])
    assert f.TestOrigin(v)==orig[v],(now,v,'origin')
   checks+=1
 return ns,vs,orig,pr,age
# Actual previously-lost reattack, exact initial state and two overdue events.
rr=[r for r in rows if 149742<=r[0]<=150113]
run(rr,[149742,149866,150113])
assert f.TestOrigin(0)==149989 and f.SynthAge(0)==2 and f.SynthProfile(0)==3
# Same-note on/off/on returning to the same pitch and velocity.
rr=[(1000,(60,53,67,0),(100,90,90,0),7),(1100,(0,53,67,0),(0,90,90,0),0),(1200,(60,53,67,0),(100,90,90,0),1),(1300,(60,53,0,0),(100,90,0,0),0)]
run(rr,[1000,1400]);assert f.TestOrigin(0)==1200 and f.SynthAge(0)==3
# Pitch round trip, with no explicit retrigger bits, must still dirty the voice.
rr=[(1000,(60,53,0,0),(100,90,0,0),0),(1100,(62,53,0,0),(100,90,0,0),0),(1200,(60,53,0,0),(100,90,0,0),0)]
run(rr,[1000,1400]);assert f.TestOrigin(0)==1200
# Onset before a preset-map boundary keeps its onset preset when a later
# unrelated event is also due after the boundary (tight third voice -> response).
rr=[(38900,(60,53,65,0),(100,90,90,0),7),(39000,(62,53,67,0),(100,90,90,0),5),(39150,(62,55,67,0),(100,90,90,0),2)]
run(rr,[38900,39200]);assert f.SynthProfile(2)==5 and f.TestOrigin(2)==39000
# Newly attacked response starts with preset7, while held lead keeps old preset.
rr=[(51400,(60,53,65,0),(100,90,90,0),7),(51600,(60,55,65,0),(100,90,90,0),2),(51690,(60,57,65,0),(100,90,90,0),2)]
run(rr,[51400,51700]);assert f.SynthProfile(0)==0 and f.TestOrigin(0)==51400
# All real records under multiple service schedules, with varied backlog sizes.
run(rows,[r[0] for r in rows])
for step in [55,80,125,250,1000,5000]:run(rows,list(range(0,241501,step))+[241500])
rng=random.Random(0xBADD1E)
for iteration in range(25):
 times=[];now=0
 while now<241500:
  now+=rng.randint(1,1200);times.append(now)
 run(rows,times)
# Preroll restores original per-voice onset/preset and aged envelopes.
for when in [0,35652,39150,51550,149990,150113,160900,188600,241399]:
 reset(rows);assert f.TestPrime(when,0)==1
 ns=[0]*4;vs=[0]*4;orig=[0]*4;pr=[0]*4
 for t,nn,vv,mask in rows:
  if t>when:break
  for v in range(4):
   if nn[v]!=ns[v] or vv[v]!=vs[v] or mask&(1<<v):orig[v]=t;pr[v]=profile(v,nn[v],t)
  ns=list(nn);vs=list(vv)
 for v in range(4):
  assert f.TestNote(v)==ns[v]
  if ns[v]:
   age=min(15,(when-orig[v])*1000//54925)
   assert f.TestOrigin(v)==orig[v] and f.SynthProfile(v)==pr[v] and f.SynthAge(v)==age
   assert f.TestVolume(v)==attenuation(vs[v],pr[v],age)
  else:assert f.TestVolume(v)==15
  checks+=1
result={'result':'PASS','voice_check_groups':checks,'source_sha256':hashlib.sha256((S/'DOSPLAY.C').read_bytes()).hexdigest(),'tested':['actual 149989/150113 reattack pair','same-note on/off/on','pitch round trip without retrigger mask','held voices across unrelated catch-up events','onset preset retained across map boundary','single-event path','all 1457 selected score records under 7 fixed and 25 randomized schedules','9 preroll positions','at most 4 envelope writes per tick and 20 total per merged service call'],'host_limit':'Host GCC C89 uses native integer widths; Microsoft C6 build remains separate.'}
(OUT/'CATCHUP-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
