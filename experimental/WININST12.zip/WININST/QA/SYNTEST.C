/* Native-host source logic regression. This does not emulate 8088 timing. */
#include <stdio.h>
#include <stdlib.h>
#include "MIDIMAP.C"
static DWORD now;
static HTASK task=1;
static unsigned checks,passWrites;
DWORD GetTickCount(void){return now;}
WORD GetWinFlags(void){return 0;}
HTASK GetCurrentTask(void){return task;}
int OpenSound(void){return 3;}
int StopSound(void){return 0;}
void CloseSound(void){}
void PsgByte(unsigned value){if(value>255)abort();++passWrites;}
#define T(x) do {++checks;if(!(x)){printf("FAIL %u %s\n",__LINE__,#x);exit(1);}}while(0)
static DWORD data(unsigned s,unsigned a,unsigned b) {
 return midiMessage(0,MODM_DATA,MIDI_COOKIE,(DWORD)s|((DWORD)a<<8)|((DWORD)b<<16),0);
}
static void tick(DWORD t){now=t;passWrites=0;T(!midiMessage(0,MODM_SYNTHUPDATE,MIDI_COOKIE,0,0));T(passWrites<=10);}
int main(void) {
 unsigned i,j,k,pr;WORD vol,p;TVOICE v;
 owner=1;reset();T(!midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,3,0));
 T(!data(0x90,60,127));T(volumeOn[0]==0);tick(110);T(volumeOn[0]==1);
 T(!data(0xc0,48,0));T(programs[0]==48);T(voicePreset[0]==0);
 T(!data(0x90,64,127));T(voicePreset[1]==3 && volumeOn[1]==12);
 T(!data(0xc1,16,0));T(!data(0x91,67,127));T(voicePreset[2]==1);
 tick(550);T(volumeOn[0]==8 && volumeOn[1]==1 && volumeOn[2]==0);
 tick(880);T(periodOn[1]!=periods[64-45]);
 T(!data(0x80,60,0));T(!notesOn[0]);tick(1000);T(!notesOn[0]);
 T(!data(0x90,60,127));T(voicePreset[0]==3);
 T(!data(0x92,72,127));T(notesOn[1]==72);T(!data(0x80,64,0));T(notesOn[1]==72);
 T(!data(0xb2,123,0));T(!notesOn[1]);T(notesOn[0] && notesOn[2]);
 T(!data(0x99,42,127));T(noiseNote==42);tick(2000);T(!noiseNote);
 T(synthMissed>0 && synthMaxGap>=1000 && synthMaxWrites<=10);
 task=2;pr=writes;T(midiMessage(0,MODM_SYNTHUPDATE,MIDI_COOKIE,0,0)==4);T(writes==pr);
 T(midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,0,0)==4);T(synthFlags==3);task=1;
 T(midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,2,0)==11);
 T(midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,0x10000UL,0)==11);
 T(midiMessage(0,MODM_SYNTHUPDATE,MIDI_COOKIE,1,0)==11);
 T(!midiMessage(0,MODM_RESET,MIDI_COOKIE,0,0));T(!DebugState(0));T(synthFlags==3);
 for(i=0;i<16;i++)T(programs[i]==0);
 T(!midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,1,0));T(!data(0xc0,80,0));T(!data(0x90,60,127));tick(3000);T(periodOn[0]==428);
 T(!midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,0,0));T(!data(0xc0,96,0));T(!data(0x90,60,127));tick(100000);T(notesOn[0]==60 && volumeOn[0]==0);
 T(!midiMessage(0,MODM_SYNTHCONFIG,MIDI_COOKIE,3,0));now=0xffffff00UL;reset();T(!data(0x90,60,127));tick(0x00000126UL);T(synthClock==10 && volumeOn[0]==8);
 T(!midiMessage(0,MODM_CLOSE,MIDI_COOKIE,0,0));T(!owner && !synthFlags && !DebugState(0));
 /* Every Program Change value on every channel is stored independently. */
 owner=1;now=100;reset();synthFlags=3;
 for(i=0;i<16;i++)for(j=0;j<128;j++) {
  T(!data(0xc0|i,j,0));T(programs[i]==j);
  if(i!=9) {T(!data(0x90|i,60,127));T(voicePreset[0]==(j>>4));T(!data(0x80|i,60,0));}
 }
 for(i=0;i<50000;i++) {
  now+=(i%19)*11u;tick(now);
  T(!data(0xc0|(i%9),i%128,0));
  T(!data(0x90|(i%9),45+i%52,1+i%127));
  if(i%3==0)T(!data(0x80|((i+2)%9),45+(i+2)%52,0));
  if(i%7==0)T(!data(0x99,35+i%47,100));
  if(i%1000==0)T(!midiMessage(0,MODM_RESET,MIDI_COOKIE,0,0));
 }
 /* Exhaust all profiles, supported periods and velocity attenuations across
    sustained ages, onset, expiry, 32-bit wrap and very long catch-up. */
 for(i=0;i<11;i++)for(j=0;j<52;j++)for(k=0;k<15;k++) {
  InstStart(&v,i,k,periods[j],0xfffffff0UL);
  for(pr=0;pr<64;pr++) {InstRead(&v,(DWORD)(0xfffffff0UL+pr),3,&p,&vol);T(p>=1&&p<=1023&&vol<=15);}
  InstRead(&v,0x7ffffff0UL,3,&p,&vol);T(p>=1&&p<=1023&&vol<=15);
 }
 printf("PASS %u checks; bounded four-voice service, program snapshots, wrap, ownership, reset and legacy mode\n",checks);return 0;
}
