static void check(int condition,const char *label) {
 ++check_count;
 if(!condition) { fprintf(stderr,"FAIL: %s\n",label);exit(1); }
}
static void reset(void) {
 began=0;phase=0;active=0;now_tick=1000;win_flags=0;
 hardware_signature=0x21;timer_ok=class_ok=window_ok=1;
 window_alive=0;timer_calls=kill_calls=destroy_calls=quit_calls=0;
 flags_calls=hardware_reads=register_calls=create_calls=0;
 translate_calls=dispatch_calls=getmessage_calls=0;
 port_count=0;live_timer=0;queue_length=queue_cursor=quit_pending=0;
 memset(port_bytes,0,sizeof(port_bytes));
 memset(port_ticks,0,sizeof(port_ticks));
 memset(&registered_class,0,sizeof(registered_class));
 registered_class.lpfnWndProc=ChimeProc;
}
static int muted(void) {
 return port_count>=4 && port_bytes[port_count-4]==0x9f &&
 port_bytes[port_count-3]==0xbf && port_bytes[port_count-2]==0xdf &&
 port_bytes[port_count-1]==0xff;
}
static void enqueue(DWORD tick,UINT m,WPARAM wp) {
 MSG *msg=&queue_messages[queue_length];
 msg->hwnd=WIN;msg->message=m;msg->wParam=wp;msg->lParam=0;
 queue_ticks[queue_length++]=tick;
}
static void timer_at(DWORD t,WPARAM id) {now_tick=t;ChimeProc(WIN,WM_TIMER,id,0);}
static void start_direct(void) {
 window_alive=1;check(ChimeProc(WIN,WM_CREATE,0,0)==0,"create succeeds");
 check(phase==7 && active && live_timer && port_count==4 && muted(),"silent startup wait");
 ChimeProc(WIN,WM_TIMER,TIMER,0);
 check(phase==0 && began==now_tick && port_count==13,"first timer starts three voices");
}
static void checktone(int n,unsigned v,unsigned p,unsigned a) {
 check(port_bytes[n]==(0x80|(v<<5)|(p&15)),"tone latch exact");
 check(port_bytes[n+1]==(p>>4),"tone data exact");
 check(port_bytes[n+2]==(0x90|(v<<5)|a),"attenuation exact");
}
int main(void) {
 int n,result;unsigned i,j;DWORD base;
 reset();win_flags=WF_PMODE;result=WinMain(WIN,NULL,"",1);
 check(result==1 && !port_count && !hardware_reads,"protected mode rejected");
 reset();result=WinMain(WIN,WIN,"",1);
 check(result==1 && !port_count && !flags_calls,"duplicate rejected");
 reset();hardware_signature=0;result=WinMain(WIN,NULL,"",1);
 check(result==2 && !port_count && !register_calls,"nonTandy rejected");
 reset();class_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==3 && !port_count && !create_calls,"class failure clean");
 reset();window_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==4 && muted() && !timer_calls && !getmessage_calls,"window failure clean");
 reset();timer_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==4 && muted() && !active && !live_timer && !getmessage_calls,"timer failure clean");
 for(i=0;i<(unsigned)port_count;i++)check((port_bytes[i]&0x9f)==0x9f,"failure only mutes");
 reset();window_alive=1;ChimeProc(WIN,WM_CREATE,0,0);timer_at(90000,TIMER+1);
 check(phase==7 && port_count==4,"foreign timer cannot start");
 timer_at(90000,TIMER);check(began==90000 && phase==0,"first timer starts fresh despite delayed desktop");
 reset();start_direct();checktone(4,0,90,6);checktone(7,1,269,10);checktone(10,2,641,11);
 n=port_count;timer_at(1299,TIMER);check(n==port_count && phase==0,"first boundary not early");
 for(i=1;i<6;i++) {
  n=port_count;timer_at(1000+onsets[i]-1,TIMER);check(n==port_count,"boundary not early");
  timer_at(1000+onsets[i],TIMER);check(phase==i,"phase advances once");checktone(n,0,notes[i],6);
  if(i==3)checktone(n+3,2,539,11);
  if(i==5){checktone(n+3,1,285,10);checktone(n+6,2,719,11);}
 }
 n=port_count;timer_at(3399,TIMER);check(n==port_count && active,"melody release not early");
 timer_at(3400,TIMER);check(phase==6 && active && port_count==n+2 && port_bytes[n]==0x9f && port_bytes[n+1]==0xbf,"two voices release at2400, bass continues");
 n=port_count;timer_at(3699,TIMER);check(n==port_count && active,"bass release not early");
 timer_at(3700,TIMER);check(!active && !live_timer && !window_alive && muted() && quit_calls==1,"2700ms allmute and unload");
 n=port_count;timer_at(100000,TIMER);check(n==port_count,"stale timer cannot restart");
 for(i=0;i<5;i++) {
  reset();start_direct();for(j=1;j<=i;j++)timer_at(1000+onsets[j],TIMER);
  timer_at(1000+onsets[i+1]+165,TIMER);check(active && phase==i+1,"165ms late accepted once");
  reset();start_direct();for(j=1;j<=i;j++)timer_at(1000+onsets[j],TIMER);
  n=port_count;timer_at(1000+onsets[i+1]+166,TIMER);
  check(!active && muted() && phase==i && port_count==n+8,"166ms late aborts no burst");
 }
 reset();start_direct();timer_at(100000,TIMER);check(!active && muted() && phase==0,"gross delay stops");
 for(i=0;i<8;i++) {
  reset();window_alive=1;ChimeProc(WIN,WM_CREATE,0,0);
  if(i<7){timer_at(1000,TIMER);for(j=1;j<=i && j<6;j++)timer_at(1000+onsets[j],TIMER);if(i==6)timer_at(3400,TIMER);}
  ChimeProc(WIN,WM_CLOSE,0,0);check(!active && !live_timer && muted() && !window_alive,"close every phase cleans");
  n=port_count;timer_at(99999,TIMER);check(n==port_count,"closed phase ignores stale timer");
 }
 reset();start_direct();n=port_count;check(ChimeProc(WIN,WM_QUERYENDSESSION,0,0)==TRUE && port_count==n,"query preserves playback");
 ChimeProc(WIN,WM_ENDSESSION,0,0);check(active && live_timer && port_count==n,"cancelled shutdown preserves playback");
 ChimeProc(WIN,WM_ENDSESSION,1,0);check(!active && !live_timer && muted(),"session end mutes");
 n=port_count;timer_at(99999,TIMER);check(n==port_count,"session stale timer ignored");
 reset();start_direct();ChimeProc(WIN,WM_DESTROY,0,0);check(!active && !live_timer && muted() && quit_calls==1,"external destroy cleans");
 reset();base=0xffffff80UL;now_tick=base;start_direct();
 for(i=1;i<6;i++){timer_at(base+onsets[i],TIMER);check(active && phase==i,"DWORD wrap note progression");}
 timer_at(base+2400,TIMER);check(phase==6 && active,"DWORD wrap release");timer_at(base+2700,TIMER);check(!active && muted(),"DWORD wrap final mute");
 reset();enqueue(1000,WM_TIMER,TIMER);for(i=1;i<6;i++)enqueue(1000+onsets[i],WM_TIMER,TIMER);
 enqueue(3400,WM_TIMER,TIMER);enqueue(3700,WM_TIMER,TIMER);result=WinMain(WIN,NULL,"",1);
 check(result==0 && !active && !live_timer && !window_alive && muted() && quit_calls==1 && dispatch_calls==8,"full loop leaves no resident task");
 check(!registered_class.hIcon && !registered_class.hCursor && !registered_class.hbrBackground,"hidden window has no display resources");
 for(i=0;i<(unsigned)port_count;i++)printf("TRACE %lu %02X\n",(unsigned long)port_ticks[i],port_bytes[i]);
 printf("PASS: %d assertions; host-only mocks of unchanged source.\n",check_count);return 0;
}
