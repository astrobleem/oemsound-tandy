#define WINVER 0x0300
#include <windows.h>
static DWORD start; static HWND cookie, psg; static int phase;
LONG FAR PASCAL WndProc(HWND w,UINT m,WPARAM wp,LPARAM lp) {
 if(m==WM_CREATE){SetTimer(w,1,100,NULL);start=GetTickCount();return 0;}
 if(m==WM_TIMER){
  if(!phase){cookie=FindWindow("CookieBench",NULL);psg=FindWindow("TandyPSGTest",NULL);
   if(cookie&&psg){SendMessage(cookie,WM_COMMAND,103,0L);SendMessage(psg,WM_COMMAND,101,0L);start=GetTickCount();phase=1;}
   else if(GetTickCount()-start>30000UL)PostMessage(w,WM_CLOSE,0,0L);
  }else if(phase==1 && GetTickCount()-start>15000UL){
    SendMessage(cookie,WM_COMMAND,102,0L);SendMessage(psg,WM_COMMAND,102,0L);
    SendMessage(psg,WM_CLOSE,0,0L);SendMessage(cookie,WM_CLOSE,0,0L);
    cookie=0;psg=0;phase=2;start=GetTickCount();
  }else if(phase==2 && GetTickCount()-start>1000UL)PostMessage(w,WM_CLOSE,0,0L);
  return 0;
 }
 if(m==WM_CLOSE){KillTimer(w,1);if(psg)SendMessage(psg,WM_CLOSE,0,0L);if(cookie)SendMessage(cookie,WM_CLOSE,0,0L);DestroyWindow(w);return 0;}
 if(m==WM_DESTROY){PostQuitMessage(0);return 0;}
 return DefWindowProc(w,m,wp,lp);
}
int PASCAL WinMain(HINSTANCE h,HINSTANCE old,LPSTR cmd,int show){
 WNDCLASS c;MSG msg;HWND w;
 c.style=0;c.lpfnWndProc=WndProc;c.cbClsExtra=0;c.cbWndExtra=0;c.hInstance=h;c.hIcon=0;c.hCursor=0;c.hbrBackground=0;c.lpszMenuName=0;c.lpszClassName="CoexTest";
 RegisterClass(&c);w=CreateWindow("CoexTest","Coex",0,0,0,0,0,0,0,h,0);
 WinExec("C:\\COOKIE.EXE",SW_SHOWNORMAL);WinExec("C:\\PSGPLAY.EXE",SW_SHOWNORMAL);
 while(GetMessage(&msg,0,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}ExitWindows(0,0);return 0;
}
