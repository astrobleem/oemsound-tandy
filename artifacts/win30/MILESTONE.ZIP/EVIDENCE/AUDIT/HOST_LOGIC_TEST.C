
/* HOST-ONLY LOGIC TEST. Not a Windows target build or hardware emulator. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
typedef uint32_t DWORD;
typedef uint16_t WORD, WPARAM;
typedef int32_t LONG, LPARAM;
typedef unsigned UINT;
typedef int HWND,HINSTANCE,HDC,HFILE,HMENU;
typedef char *LPSTR;
typedef struct { int left,top,right,bottom; } RECT;
typedef struct { int dummy; } PAINTSTRUCT;
#define FAR
#define PASCAL
#define TRUE 1
#define HFILE_ERROR (-1)
#define WM_CREATE 1
#define WM_DESTROY 2
#define WM_CLOSE 0x10
#define WM_ENDSESSION 0x16
#define WM_KEYDOWN 0x100
#define WM_COMMAND 0x111
#define WM_TIMER 0x113
#define WM_PAINT 15
#define VK_ESCAPE 27
#define WS_CHILD 1
#define WS_VISIBLE 2
#define WS_TABSTOP 4
#define SYSTEM_FIXED_FONT 1
static DWORD now_tick;
static int timer_ok, timer_calls, kill_calls, close_posts, destroys;
static int quit_calls, save_calls, port_count, check_count;
static unsigned char port_bytes[100000];
static DWORD GetTickCount(void) { return now_tick; }
static void record_port(unsigned char v) { if(port_count<100000) port_bytes[port_count++]=v; }
static int SetTimer(HWND w,int t,int ms,void *cb) { ++timer_calls;return timer_ok; }
static int KillTimer(HWND w,int t) { ++kill_calls;return 1; }
static int PostMessage(HWND w,UINT m,WPARAM p,LPARAM l) { if(m==WM_CLOSE)++close_posts;return 1; }
static HFILE _lcreat(char *p,int a) { ++save_calls;return HFILE_ERROR; }
static int _lwrite(HFILE f,char *p,int n) { return n; }
static int _lclose(HFILE f) { return 0; }
static int wsprintf(char *buf,const char *fmt,...) { int r;va_list a;va_start(a,fmt);r=vsprintf(buf,fmt,a);va_end(a);return r; }
#define lstrlen strlen
#define InvalidateRect(w,r,e) ((void)0)
#define EnableWindow(w,e) ((void)0)
#define CreateWindow(...) 2
#define BeginPaint(w,p) 1
#define SelectObject(d,o) ((void)0)
#define GetStockObject(o) 1
#define TextOut(...) ((void)0)
#define EndPaint(w,p) ((void)0)
#define DestroyWindow(w) (++destroys)
#define PostQuitMessage(x) (++quit_calls)
#define DefWindowProc(...) 0
/* Native Windows 3.0 / 8088 PSG milestone. No IRQ or PIT hooks. */
#define WINVER 0x0300

#define PLAY 101
#define STOP 102
#define TIMER 1
static HINSTANCE instance;
static HWND playButton, stopButton;
static int playing, stage, automatic, testStep;
static DWORD tickStart, biosStart, irq8Start, irq1cStart;
static DWORD started, stageStarted, stopped;
static char *status = "Ready";
struct event { DWORD tick; unsigned char value; };
static struct event trace[128];
static unsigned traces, traceHead, dropped;
/* OUT has no side effects on IF. Sixteen NOPs allow the SN76489 write
   settling interval at the target 4.77 MHz 8088. */
static void output(unsigned char value)
{
    unsigned index;
    if (traces < 128) index = (traceHead + traces++) & 127;
    else { index = traceHead; traceHead = (traceHead + 1) & 127;
        if (dropped < 65535U) ++dropped; }
    trace[index].tick = GetTickCount(); trace[index].value = value;
    record_port(value);
}
static void silence(void)
{
    output(0x9f); output(0xbf); output(0xdf); output(0xff);
}
static void tone(unsigned channel, unsigned period)
{
    output((unsigned char)(0x80 | (channel << 5) | (period & 15)));
    output((unsigned char)((period >> 4) & 63));
    output((unsigned char)(0x94 | (channel << 5)));
}
static void redraw(HWND w)
{
    RECT r;
    r.left = 4; r.top = 42; r.right = 148; r.bottom = 58;
    InvalidateRect(w, &r, TRUE);
}
static void stop(HWND w)
{
    KillTimer(w, TIMER); playing = 0; stage = 0;
    silence(); status = "Stopped: muted";
    EnableWindow(playButton, TRUE); redraw(w);
}
static void play(HWND w)
{
    stop(w);
    if (!SetTimer(w, TIMER, 50, NULL)) {
        status = "No timer"; redraw(w);
        if (automatic) PostMessage(w, WM_CLOSE, 0, 0L);
        return;
    }
    started = GetTickCount(); stageStarted = started; playing = 1; stage = 1;
    tone(0, 427); status = "Voice 1: C4";
    redraw(w);
}
/* Read-only diagnostic snapshots, used only after real-mode check. */
static DWORD readFar(WORD segment, WORD offset) { return 0; }
static int argIs(LPSTR cmd, char *s)
{
    while (*cmd == ' ') ++cmd;
    while (*s && *cmd == *s) { ++s; ++cmd; }
    while (*cmd == ' ') ++cmd;
    return *s == 0 && *cmd == 0;
}
static void saveTrace(void)
{
    HFILE f; char line[96]; unsigned i, index;
    f = _lcreat("C:\\PSGTRACE.LOG", 0);
    if (f == HFILE_ERROR) return;
    wsprintf(line, "MODE %u DROPPED %u\r\n", automatic, dropped);
    _lwrite(f, line, lstrlen(line));
    wsprintf(line, "TICKS %lu %lu BIOS %lu %lu\r\n", tickStart,
        GetTickCount(), biosStart, readFar(0x40, 0x6c));
    _lwrite(f, line, lstrlen(line));
    wsprintf(line, "IRQ8 %08lX %08lX IRQ1C %08lX %08lX\r\n", irq8Start,
        readFar(0, 0x20), irq1cStart, readFar(0, 0x70));
    _lwrite(f, line, lstrlen(line));
    for (i = 0; i < traces; ++i) {
        index = (traceHead + i) & 127;
        wsprintf(line, "%lu %02X\r\n", trace[index].tick,
                 (unsigned)trace[index].value);
        _lwrite(f, line, lstrlen(line));
    }
    _lclose(f);
}
LONG FAR PASCAL WndProc(HWND w, UINT m, WPARAM wp, LPARAM lp)
{
    HDC dc; PAINTSTRUCT ps; DWORD elapsed;
    switch (m) {
    case WM_CREATE:
        playButton = CreateWindow("BUTTON", "&Play", WS_CHILD | WS_VISIBLE |
            WS_TABSTOP, 8, 8, 60, 24, w, (HMENU)PLAY, instance, NULL);
        stopButton = CreateWindow("BUTTON", "&Stop", WS_CHILD | WS_VISIBLE |
            WS_TABSTOP, 76, 8, 60, 24, w, (HMENU)STOP, instance, NULL);
        silence();
        if (automatic) {
            PostMessage(w, WM_COMMAND, PLAY, 0L);
        }
        return 0;
    case WM_COMMAND:
        if (wp == PLAY) play(w);
        if (wp == STOP) stop(w);
        return 0;
    case WM_KEYDOWN:
        if (wp == VK_ESCAPE || wp == 'S') stop(w);
        if (wp == 'P') play(w);
        return 0;
    case WM_TIMER:
        if (wp != TIMER) return 0;
        if (!playing) {
            if (automatic && testStep && GetTickCount() - stopped >= 700L)
                PostMessage(w, WM_CLOSE, 0, 0L);
            return 0;
        }
        elapsed = GetTickCount() - started;
        if (automatic == 3 && elapsed >= 250L) {
            PostMessage(w, WM_CLOSE, 0, 0L); return 0;
        }
        if (automatic == 2 && elapsed >= 250L) {
            stop(w); testStep = 1; stopped = GetTickCount();
            if (!SetTimer(w, TIMER, 50, NULL))
                PostMessage(w, WM_CLOSE, 0, 0L);
            return 0;
        }
        elapsed = GetTickCount() - stageStarted;
        if (stage == 3 && elapsed >= 1200L) {
            stop(w);
            if (automatic) { testStep = 1; stopped = GetTickCount();
                if (!SetTimer(w, TIMER, 50, NULL))
                    PostMessage(w, WM_CLOSE, 0, 0L); }
        } else {
            if (elapsed >= 600L && stage == 1) {
                tone(1, 339); stage = 2; stageStarted = GetTickCount();
                status = "C4 + E4"; redraw(w);
            } else if (elapsed >= 600L && stage == 2) {
                tone(2, 285); stage = 3; stageStarted = GetTickCount();
                status = "C4 + E4 + G4"; redraw(w);
            }
        }
        return 0;
    case WM_PAINT:
        dc = BeginPaint(w, &ps);
        SelectObject(dc, GetStockObject(SYSTEM_FIXED_FONT));
        TextOut(dc, 8, 44, status, lstrlen(status));
        TextOut(dc, 8, 64, "3 tones: ~2.4s", 14);
        TextOut(dc, 8, 80, "Esc/S = mute", 12);
        EndPaint(w, &ps); return 0;
    case WM_ENDSESSION:
        if (wp) { stop(w); saveTrace(); }
        return 0;
    case WM_CLOSE:
        stop(w); DestroyWindow(w); return 0;
    case WM_DESTROY:
        stop(w); PostQuitMessage(0); return 0;
    }
    return DefWindowProc(w, m, wp, lp);
}

static void check(int condition,const char *label) { ++check_count;if(!condition){fprintf(stderr,"FAIL: %s\n",label);exit(1);} }
static void reset(int mode) {
 playing=stage=testStep=0;automatic=mode;
 traces=traceHead=dropped=0;started=stageStarted=stopped=0;
 now_tick=1000;timer_ok=1;timer_calls=kill_calls=close_posts=0;
 destroys=quit_calls=save_calls=port_count=0;
 memset(trace,0,sizeof(trace));
}
static int tail_muted(void) {
 return port_count>=4 && port_bytes[port_count-4]==0x9f &&
 port_bytes[port_count-3]==0xbf && port_bytes[port_count-2]==0xdf &&
 port_bytes[port_count-1]==0xff;
}
int main(void) {
 int mode,i; unsigned before;
 for(mode=0;mode<=3;++mode) {
  reset(mode);timer_ok=0;play(1);
  check(!playing && stage==0,"failed SetTimer leaves playback stopped");
  check(tail_muted(),"failed SetTimer keeps all PSG channels muted");
  check(close_posts==(mode!=0),"failed SetTimer closes automatic modes only");
 }
 reset(1);play(1);now_tick=10000;WndProc(1,WM_TIMER,TIMER,0);
 check(stage==2 && port_bytes[port_count-1]==0xb4,"late first tick adds E4 rather than ending");
 now_tick=20000;WndProc(1,WM_TIMER,TIMER,0);
 check(stage==3 && port_bytes[port_count-1]==0xd4,"late second tick adds G4");
 now_tick=21199;WndProc(1,WM_TIMER,TIMER,0);check(playing,"G4 held for at least1200 ms");
 now_tick=21200;WndProc(1,WM_TIMER,TIMER,0);check(!playing && testStep && tail_muted(),"full sequence mutes after G4 hold");
 now_tick=21899;WndProc(1,WM_TIMER,TIMER,0);check(!close_posts,"700-ms post-stop quiet period retained");
 now_tick=21900;WndProc(1,WM_TIMER,TIMER,0);check(close_posts==1,"full sequence posts close after quiet period");
 reset(2);play(1);now_tick=1250;timer_ok=0;WndProc(1,WM_TIMER,TIMER,0);
 check(!playing && tail_muted() && close_posts==1,"early-stop rearm failure mutes and closes");
 reset(1);play(1);stage=3;stageStarted=0;now_tick=1200;timer_ok=0;WndProc(1,WM_TIMER,TIMER,0);
 check(!playing && tail_muted() && close_posts==1,"normal-stop rearm failure mutes and closes");
 reset(3);play(1);now_tick=1250;WndProc(1,WM_TIMER,TIMER,0);
 check(close_posts==1 && playing,"closetest requests close while tone remains active");
 WndProc(1,WM_CLOSE,0,0);check(!playing && tail_muted() && destroys==1,"WM_CLOSE mutes before destroy");
 reset(0);play(1);before=port_count;WndProc(1,WM_ENDSESSION,0,0);
 check(playing && port_count==before && save_calls==0,"cancelled session exit leaves playback unchanged");
 WndProc(1,WM_ENDSESSION,1,0);
 check(!playing && tail_muted() && save_calls==1,"confirmed session exit mutes and attempts log save");
 reset(0);for(i=0;i<300;++i){now_tick=(DWORD)i;output((unsigned char)i);}
 check(traces==128 && dropped==172 && traceHead==44,"rolling trace counters after overflow");
 for(i=0;i<128;++i)check(trace[(traceHead+i)&127].tick==(DWORD)(172+i) && trace[(traceHead+i)&127].value==(unsigned char)(172+i),"trace retains newest128 in chronological order");
 silence();check(trace[(traceHead+traces-4)&127].value==0x9f && trace[(traceHead+traces-1)&127].value==0xff,"mute tail retained after trace overflow");
 dropped=65535;output(0);check(dropped==65535,"dropped counter saturates");
 reset(0);now_tick=0xffffff00UL;play(1);now_tick=0x158;WndProc(1,WM_TIMER,TIMER,0);
 check(stage==2,"DWORD elapsed arithmetic handles clock wrap");
 check(argIs(" /test ","/test") && !argIs("/test x","/test") && !argIs("/testx","/test"),"exact command parser rejects trailing tokens");
 printf("PASS: %d assertions; host-only stubbed logic checks.\n",check_count);
 return 0;
}
