/* Host-only mocks: no target build and no physical I/O. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t DWORD;
typedef uint16_t WORD, WPARAM;
typedef int32_t LONG, LPARAM;
typedef unsigned UINT;
typedef void *HWND;
typedef void *HINSTANCE;
typedef char *LPSTR;
typedef struct { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; } MSG;
typedef struct {
 UINT style; LONG (*lpfnWndProc)(HWND,UINT,WPARAM,LPARAM);
 int cbClsExtra,cbWndExtra; HINSTANCE hInstance;
 void *hIcon,*hCursor,*hbrBackground;
 const char *lpszMenuName,*lpszClassName;
} WNDCLASS;
#define FAR
#define PASCAL
#define TRUE 1
#define WF_PMODE 1
#define WS_POPUP 0x80000000UL
#define WM_CREATE 1
#define WM_DESTROY 2
#define WM_CLOSE 0x10
#define WM_QUERYENDSESSION 0x11
#define WM_ENDSESSION 0x16
#define WM_TIMER 0x113
#define WIN ((HWND)(uintptr_t)1)
static DWORD now_tick;
static unsigned win_flags;
static unsigned char hardware_signature;
static int timer_ok,class_ok,window_ok,window_alive;
static int timer_calls,kill_calls,destroy_calls,quit_calls;
static int flags_calls,hardware_reads,register_calls,create_calls;
static int translate_calls,dispatch_calls,getmessage_calls;
static int port_count,check_count,live_timer;
static unsigned char port_bytes[8192];
static DWORD port_ticks[8192];
static MSG queue_messages[64];
static DWORD queue_ticks[64];
static int queue_length,queue_cursor,quit_pending;
static WNDCLASS registered_class;
static DWORD GetTickCount(void) { return now_tick; }
static unsigned GetWinFlags(void) { ++flags_calls;return win_flags; }
static unsigned char read_signature(void) { ++hardware_reads;return hardware_signature; }
static void record_port(unsigned char v) {
 if(port_count>=8192) { fprintf(stderr,"Port trace overflow\n");exit(90); }
 port_bytes[port_count]=v;port_ticks[port_count++]=now_tick;
}
static int SetTimer(HWND w,int id,int ms,void *callback) {
 (void)w;(void)id;(void)ms;(void)callback;
 ++timer_calls;if(timer_ok)live_timer=1;return timer_ok;
}
static int KillTimer(HWND w,int id) {
 (void)w;(void)id;++kill_calls;live_timer=0;return 1;
}
static int RegisterClass(WNDCLASS *c) {
 ++register_calls;registered_class=*c;return class_ok;
}
static int DestroyWindow(HWND w) {
 ++destroy_calls;
 if(window_alive) {
  window_alive=0;registered_class.lpfnWndProc(w,WM_DESTROY,0,0);
 }
 return 1;
}
static HWND CreateWindow(const char *cls,const char *name,DWORD style,
 int x,int y,int width,int height,HWND parent,void *menu,HINSTANCE inst,
 void *param) {
 LONG result;
 (void)cls;(void)name;(void)style;(void)x;(void)y;(void)width;
 (void)height;(void)parent;(void)menu;(void)inst;(void)param;
 ++create_calls;if(!window_ok)return NULL;
 window_alive=1;result=registered_class.lpfnWndProc(WIN,WM_CREATE,0,0);
 if(result==-1) { DestroyWindow(WIN);return NULL; }
 return WIN;
}
static void PostQuitMessage(int result) { (void)result;++quit_calls;quit_pending=1; }
static int GetMessage(MSG *msg,HWND w,unsigned lo,unsigned hi) {
 (void)w;(void)lo;(void)hi;++getmessage_calls;
 if(quit_pending) { memset(msg,0,sizeof(*msg));return 0; }
 if(queue_cursor>=queue_length) {
  fprintf(stderr,"Unexpected empty mock message queue\n");exit(91);
 }
 *msg=queue_messages[queue_cursor];now_tick=queue_ticks[queue_cursor++];return 1;
}
static int TranslateMessage(const MSG *msg) { (void)msg;++translate_calls;return 1; }
static LONG DispatchMessage(const MSG *msg) {
 ++dispatch_calls;
 return registered_class.lpfnWndProc(msg->hwnd,msg->message,msg->wParam,msg->lParam);
}
static LONG DefWindowProc(HWND w,UINT m,WPARAM p,LPARAM l) {
 (void)w;(void)m;(void)p;(void)l;return 0;
}

/* Optional one-shot startup chime for known Tandy PSG hardware.
   Windows 3.0 real mode / 8086. No IRQ/PIT changes or resident helper. */
#define WINVER 0x0300

#define TIMER 1
static DWORD began;
static unsigned phase;
static int active;
static void psgByte(unsigned char value)
{
    record_port(value);
}
static void muteAll(void)
{
    psgByte(0x9f); psgByte(0xbf); psgByte(0xdf); psgByte(0xff);
}
static void tone(unsigned voice, unsigned period)
{
    psgByte((unsigned char)(0x80 | (voice << 5) | (period & 15)));
    psgByte((unsigned char)((period >> 4) & 63));
    psgByte((unsigned char)(0x96 | (voice << 5)));
}
static void cleanup(HWND w)
{
    KillTimer(w, TIMER); active = 0; muteAll();
}
static void finish(HWND w)
{
    cleanup(w); DestroyWindow(w);
}
LONG FAR PASCAL ChimeProc(HWND w, UINT m, WPARAM wp, LPARAM lp)
{
    DWORD elapsed, due;
    switch (m) {
    case WM_CREATE:
        muteAll();
        if (!SetTimer(w, TIMER, 55, NULL)) return -1;
        phase = 4; active = 1;
        /* Wait for the first delivered timer, so initial desktop painting
           can finish before any sustained tone begins. No startup wait. */
        return 0;
    case WM_TIMER:
        if (wp != TIMER || !active) return 0;
        if (phase == 4) {
            began = GetTickCount(); phase = 0;
            tone(0, 214); /* C5, approximately 523 Hz. */
            return 0;
        }
        elapsed = GetTickCount() - began;
        /* Never play a burst of overdue notes during a slow startup.
           Normal completion is 825 ms. An overdue transition ends quietly. */
        if (elapsed >= 825L) { finish(w); return 0; }
        due = phase == 0 ? 165L : phase == 1 ? 330L : 650L;
        if (elapsed > due + 220L) { finish(w); return 0; }
        if (elapsed < due) return 0;
        if (phase == 0) tone(1, 170);       /* E5, approximately 658 Hz. */
        else if (phase == 1) tone(2, 127);  /* A5, approximately 881 Hz. */
        else if (phase == 2) {
            psgByte(0x9a); psgByte(0xba); psgByte(0xda);
        }
        if (phase < 3) ++phase;
        return 0;
    case WM_QUERYENDSESSION:
        return TRUE;
    case WM_ENDSESSION:
        if (wp) cleanup(w);
        return 0;
    case WM_CLOSE:
        finish(w); return 0;
    case WM_DESTROY:
        cleanup(w); PostQuitMessage(0); return 0;
    }
    return DefWindowProc(w, m, wp, lp);
}
int PASCAL WinMain(HINSTANCE inst, HINSTANCE previous, LPSTR cmd, int show)
{
    WNDCLASS c; HWND w; MSG msg;
    /* Opt-in is for a known original Tandy. Signature is only a fail-closed
       compatibility guard; it does not identify an exact EX/HX model. */
    if (previous || (GetWinFlags() & WF_PMODE)) return 1;
    if (read_signature() != 0x21) return 2;
    c.style = 0; c.lpfnWndProc = ChimeProc;
    c.cbClsExtra = 0; c.cbWndExtra = 0; c.hInstance = inst;
    c.hIcon = NULL; c.hCursor = NULL; c.hbrBackground = NULL;
    c.lpszMenuName = NULL; c.lpszClassName = "TandyStartupChime";
    if (!RegisterClass(&c)) return 3;
    w = CreateWindow("TandyStartupChime", "Tandy startup chime", WS_POPUP,
        0, 0, 0, 0, NULL, NULL, inst, NULL);
    if (!w) { muteAll(); return 4; }
    /* Deliberately no ShowWindow: the hidden owner only receives messages.
       GetMessage yields while Program Manager and other startup apps run. */
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg); DispatchMessage(&msg);
    }
    muteAll(); return msg.wParam;
}

static void check(int condition,const char *label) {
 ++check_count;
 if(!condition) { fprintf(stderr,"FAIL: %s\n",label);exit(1); }
}
static void reset(void) {
 began=0;phase=0;active=0;now_tick=1000;win_flags=0;
 hardware_signature=0x21;timer_ok=class_ok=window_ok=1;
 window_alive=0;timer_calls=kill_calls=destroy_calls=quit_calls=0;
 flags_calls=hardware_reads=register_calls=create_calls=0;
 translate_calls=dispatch_calls=getmessage_calls=0;
 port_count=0;live_timer=0;queue_length=queue_cursor=quit_pending=0;
 memset(port_bytes,0,sizeof(port_bytes));
 memset(port_ticks,0,sizeof(port_ticks));
 memset(&registered_class,0,sizeof(registered_class));
 registered_class.lpfnWndProc=ChimeProc;
}
static int muted(void) {
 return port_count>=4 && port_bytes[port_count-4]==0x9f &&
 port_bytes[port_count-3]==0xbf && port_bytes[port_count-2]==0xdf &&
 port_bytes[port_count-1]==0xff;
}
static void enqueue(DWORD tick,UINT m,WPARAM wp) {
 MSG *msg=&queue_messages[queue_length];
 msg->hwnd=WIN;msg->message=m;msg->wParam=wp;msg->lParam=0;
 queue_ticks[queue_length++]=tick;
}
static void start_direct(void) {
 window_alive=1;
 check(ChimeProc(WIN,WM_CREATE,0,0)==0,"WM_CREATE success");
 check(active && live_timer && phase==4 && port_count==4 && muted(),
       "WM_CREATE waits silently with timer armed");
 ChimeProc(WIN,WM_TIMER,TIMER,0);
 check(port_count==7 && port_bytes[4]==0x86 &&
       port_bytes[5]==0x0d && port_bytes[6]==0x96,
       "initial C5 follows four-channel mute");
}
static void timer_at(DWORD tick,WPARAM id) {
 now_tick=tick;ChimeProc(WIN,WM_TIMER,id,0);
}
int main(void) {
 int n,result; unsigned i;
 reset();win_flags=WF_PMODE;
 result=WinMain(WIN,NULL,"",1);
 check(result==1 && flags_calls==1 && !hardware_reads && !port_count &&
       !register_calls && !create_calls,"protected mode rejected before hardware or GUI");
 reset();result=WinMain(WIN,WIN,"",1);
 check(result==1 && !flags_calls && !hardware_reads && !port_count &&
       !register_calls && !create_calls,"duplicate rejected with no hardware or API effects");
 reset();hardware_signature=0;
 result=WinMain(WIN,NULL,"",1);
 check(result==2 && hardware_reads==1 && !port_count && !register_calls &&
       !create_calls,"unknown hardware rejected before PSG output");
 reset();class_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==3 && register_calls==1 && !create_calls && !port_count,
       "class registration failure has no hardware output");
 reset();window_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==4 && !timer_calls && muted() && !getmessage_calls,
       "window creation failure is muted and exits");
 reset();timer_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==4 && timer_calls==1 && !active && !live_timer && muted() &&
       !getmessage_calls,"timer allocation failure exits with all channels muted");
 for(i=0;i<(unsigned)port_count;++i)
  check((port_bytes[i]&0x9f)==0x9f,"timer failure emits only mute writes");
 reset();window_alive=1;ChimeProc(WIN,WM_CREATE,0,0);
 check(port_count==4 && muted() && active && phase==4,
       "initial desktop load has no sustained tone");
 timer_at(100000,TIMER+1);
 check(port_count==4 && phase==4,"foreign timer cannot start delayed chime");
 timer_at(100000,TIMER);
 check(active && phase==0 && began==100000 && port_count==7,
       "late first delivery starts a fresh timeline after silent wait");
 timer_at(100165,TIMER);check(phase==1,"delayed start preserves E5 transition");
 timer_at(100330,TIMER);check(phase==2,"delayed start preserves A5 transition");
 timer_at(100650,TIMER);check(phase==3,"delayed start preserves fade transition");
 timer_at(100825,TIMER);check(!active && muted(),"delayed start finishes and mutes normally");
 reset();window_alive=1;ChimeProc(WIN,WM_CREATE,0,0);ChimeProc(WIN,WM_CLOSE,0,0);
 check(!active && !live_timer && muted() && quit_calls==1,
       "close while waiting silently exits without starting tone");
 reset();start_direct();n=port_count;timer_at(1165,TIMER+1);
 check(port_count==n && phase==0,"foreign timer ignored");
 timer_at(1164,TIMER);check(port_count==n && phase==0,"first note boundary not early");
 timer_at(1165,TIMER);
 check(phase==1 && port_count==n+3 && port_bytes[n]==0xaa &&
       port_bytes[n+1]==0x0a && port_bytes[n+2]==0xb6,"E5 added at165 ms");
 n=port_count;timer_at(1329,TIMER);
 check(port_count==n && phase==1,"second note boundary not early");
 timer_at(1330,TIMER);
 check(phase==2 && port_count==n+3 && port_bytes[n]==0xcf &&
       port_bytes[n+1]==0x07 && port_bytes[n+2]==0xd6,"A5 added at330 ms");
 n=port_count;timer_at(1649,TIMER);
 check(port_count==n && phase==2,"fade boundary not early");
 timer_at(1650,TIMER);
 check(phase==3 && port_count==n+3 && port_bytes[n]==0x9a &&
       port_bytes[n+1]==0xba && port_bytes[n+2]==0xda,"voices fade at650 ms");
 n=port_count;timer_at(1824,TIMER);
 check(active && port_count==n && !quit_calls,"completion boundary not early");
 timer_at(1825,TIMER);
 check(!active && !live_timer && !window_alive && muted() &&
       destroy_calls==1 && quit_calls==1,"825-ms completion mutes, destroys and quits");
 n=port_count;timer_at(1900,TIMER);
 check(port_count==n && !active,"stale timer after destruction cannot restart sound");
 reset();start_direct();timer_at(1385,TIMER);
 check(active && phase==1,"220-ms late transition tolerated");
 reset();start_direct();timer_at(1386,TIMER);
 check(!active && muted() && destroy_calls==1,"221-ms late first transition ends quietly");
 reset();start_direct();timer_at(1165,TIMER);timer_at(1551,TIMER);
 check(!active && muted() && phase==1,"late second transition cannot add overdue A5");
 reset();start_direct();timer_at(100000,TIMER);
 check(!active && muted() && phase==0,"grossly late first timer skips all overdue notes");
 reset();start_direct();n=port_count;
 check(ChimeProc(WIN,WM_QUERYENDSESSION,0,0)==TRUE && port_count==n && active,
       "session-end query succeeds without premature shutdown");
 ChimeProc(WIN,WM_ENDSESSION,0,0);
 check(port_count==n && active && live_timer,"cancelled session exit leaves playback alone");
 ChimeProc(WIN,WM_ENDSESSION,1,0);
 check(!active && !live_timer && muted(),"confirmed session exit cancels timer and mutes");
 n=port_count;timer_at(1825,TIMER);
 check(port_count==n,"late timer after end-session ignored");
 reset();start_direct();ChimeProc(WIN,WM_CLOSE,0,0);
 check(!active && !live_timer && muted() && !window_alive &&
       destroy_calls==1 && quit_calls==1,"external close cleans up and exits");
 reset();start_direct();ChimeProc(WIN,WM_DESTROY,0,0);
 check(!active && !live_timer && muted() && quit_calls==1,
       "external destroy cleans up and posts quit");
 reset();now_tick=0xffffff80UL;start_direct();timer_at(0x25,TIMER);
 check(active && phase==1,"DWORD timer arithmetic survives wrap at first transition");
 timer_at(0xca,TIMER);check(active && phase==2,"DWORD wrap second transition");
 timer_at(0x20a,TIMER);check(active && phase==3,"DWORD wrap fade transition");
 timer_at(0x2b9,TIMER);check(!active && muted(),"DWORD wrap825-ms completion");
 reset();enqueue(1000,WM_TIMER,TIMER);enqueue(1165,WM_TIMER,TIMER);enqueue(1330,WM_TIMER,TIMER);
 enqueue(1650,WM_TIMER,TIMER);enqueue(1825,WM_TIMER,TIMER);
 result=WinMain(WIN,NULL,"",1);
 check(result==0 && !active && !live_timer && !window_alive && muted() &&
       quit_calls==1 && getmessage_calls==6 && dispatch_calls==5 &&
       translate_calls==5,"full WinMain message loop quits without resident window or timer");
 check(registered_class.style==0 && !registered_class.hCursor &&
       !registered_class.hIcon && !registered_class.hbrBackground,
       "hidden message window has no display resources");
 printf("PASS: %d assertions; host-only mocks of unchanged source.\n",check_count);
 return 0;
}
