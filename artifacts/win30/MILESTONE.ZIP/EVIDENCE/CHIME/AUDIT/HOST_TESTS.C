static void check(int condition,const char *label) {
 ++check_count;
 if(!condition) { fprintf(stderr,"FAIL: %s\n",label);exit(1); }
}
static void reset(void) {
 began=0;phase=0;active=0;now_tick=1000;win_flags=0;
 hardware_signature=0x21;timer_ok=class_ok=window_ok=1;
 window_alive=0;timer_calls=kill_calls=destroy_calls=quit_calls=0;
 flags_calls=hardware_reads=register_calls=create_calls=0;
 translate_calls=dispatch_calls=getmessage_calls=0;
 port_count=0;live_timer=0;queue_length=queue_cursor=quit_pending=0;
 memset(port_bytes,0,sizeof(port_bytes));
 memset(port_ticks,0,sizeof(port_ticks));
 memset(&registered_class,0,sizeof(registered_class));
 registered_class.lpfnWndProc=ChimeProc;
}
static int muted(void) {
 return port_count>=4 && port_bytes[port_count-4]==0x9f &&
 port_bytes[port_count-3]==0xbf && port_bytes[port_count-2]==0xdf &&
 port_bytes[port_count-1]==0xff;
}
static void enqueue(DWORD tick,UINT m,WPARAM wp) {
 MSG *msg=&queue_messages[queue_length];
 msg->hwnd=WIN;msg->message=m;msg->wParam=wp;msg->lParam=0;
 queue_ticks[queue_length++]=tick;
}
static void start_direct(void) {
 window_alive=1;
 check(ChimeProc(WIN,WM_CREATE,0,0)==0,"WM_CREATE success");
 check(active && live_timer && phase==4 && port_count==4 && muted(),
       "WM_CREATE waits silently with timer armed");
 ChimeProc(WIN,WM_TIMER,TIMER,0);
 check(port_count==7 && port_bytes[4]==0x86 &&
       port_bytes[5]==0x0d && port_bytes[6]==0x96,
       "initial C5 follows four-channel mute");
}
static void timer_at(DWORD tick,WPARAM id) {
 now_tick=tick;ChimeProc(WIN,WM_TIMER,id,0);
}
int main(void) {
 int n,result; unsigned i;
 reset();win_flags=WF_PMODE;
 result=WinMain(WIN,NULL,"",1);
 check(result==1 && flags_calls==1 && !hardware_reads && !port_count &&
       !register_calls && !create_calls,"protected mode rejected before hardware or GUI");
 reset();result=WinMain(WIN,WIN,"",1);
 check(result==1 && !flags_calls && !hardware_reads && !port_count &&
       !register_calls && !create_calls,"duplicate rejected with no hardware or API effects");
 reset();hardware_signature=0;
 result=WinMain(WIN,NULL,"",1);
 check(result==2 && hardware_reads==1 && !port_count && !register_calls &&
       !create_calls,"unknown hardware rejected before PSG output");
 reset();class_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==3 && register_calls==1 && !create_calls && !port_count,
       "class registration failure has no hardware output");
 reset();window_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==4 && !timer_calls && muted() && !getmessage_calls,
       "window creation failure is muted and exits");
 reset();timer_ok=0;result=WinMain(WIN,NULL,"",1);
 check(result==4 && timer_calls==1 && !active && !live_timer && muted() &&
       !getmessage_calls,"timer allocation failure exits with all channels muted");
 for(i=0;i<(unsigned)port_count;++i)
  check((port_bytes[i]&0x9f)==0x9f,"timer failure emits only mute writes");
 reset();window_alive=1;ChimeProc(WIN,WM_CREATE,0,0);
 check(port_count==4 && muted() && active && phase==4,
       "initial desktop load has no sustained tone");
 timer_at(100000,TIMER+1);
 check(port_count==4 && phase==4,"foreign timer cannot start delayed chime");
 timer_at(100000,TIMER);
 check(active && phase==0 && began==100000 && port_count==7,
       "late first delivery starts a fresh timeline after silent wait");
 timer_at(100165,TIMER);check(phase==1,"delayed start preserves E5 transition");
 timer_at(100330,TIMER);check(phase==2,"delayed start preserves A5 transition");
 timer_at(100650,TIMER);check(phase==3,"delayed start preserves fade transition");
 timer_at(100825,TIMER);check(!active && muted(),"delayed start finishes and mutes normally");
 reset();window_alive=1;ChimeProc(WIN,WM_CREATE,0,0);ChimeProc(WIN,WM_CLOSE,0,0);
 check(!active && !live_timer && muted() && quit_calls==1,
       "close while waiting silently exits without starting tone");
 reset();start_direct();n=port_count;timer_at(1165,TIMER+1);
 check(port_count==n && phase==0,"foreign timer ignored");
 timer_at(1164,TIMER);check(port_count==n && phase==0,"first note boundary not early");
 timer_at(1165,TIMER);
 check(phase==1 && port_count==n+3 && port_bytes[n]==0xaa &&
       port_bytes[n+1]==0x0a && port_bytes[n+2]==0xb6,"E5 added at165 ms");
 n=port_count;timer_at(1329,TIMER);
 check(port_count==n && phase==1,"second note boundary not early");
 timer_at(1330,TIMER);
 check(phase==2 && port_count==n+3 && port_bytes[n]==0xcf &&
       port_bytes[n+1]==0x07 && port_bytes[n+2]==0xd6,"A5 added at330 ms");
 n=port_count;timer_at(1649,TIMER);
 check(port_count==n && phase==2,"fade boundary not early");
 timer_at(1650,TIMER);
 check(phase==3 && port_count==n+3 && port_bytes[n]==0x9a &&
       port_bytes[n+1]==0xba && port_bytes[n+2]==0xda,"voices fade at650 ms");
 n=port_count;timer_at(1824,TIMER);
 check(active && port_count==n && !quit_calls,"completion boundary not early");
 timer_at(1825,TIMER);
 check(!active && !live_timer && !window_alive && muted() &&
       destroy_calls==1 && quit_calls==1,"825-ms completion mutes, destroys and quits");
 n=port_count;timer_at(1900,TIMER);
 check(port_count==n && !active,"stale timer after destruction cannot restart sound");
 reset();start_direct();timer_at(1385,TIMER);
 check(active && phase==1,"220-ms late transition tolerated");
 reset();start_direct();timer_at(1386,TIMER);
 check(!active && muted() && destroy_calls==1,"221-ms late first transition ends quietly");
 reset();start_direct();timer_at(1165,TIMER);timer_at(1551,TIMER);
 check(!active && muted() && phase==1,"late second transition cannot add overdue A5");
 reset();start_direct();timer_at(100000,TIMER);
 check(!active && muted() && phase==0,"grossly late first timer skips all overdue notes");
 reset();start_direct();n=port_count;
 check(ChimeProc(WIN,WM_QUERYENDSESSION,0,0)==TRUE && port_count==n && active,
       "session-end query succeeds without premature shutdown");
 ChimeProc(WIN,WM_ENDSESSION,0,0);
 check(port_count==n && active && live_timer,"cancelled session exit leaves playback alone");
 ChimeProc(WIN,WM_ENDSESSION,1,0);
 check(!active && !live_timer && muted(),"confirmed session exit cancels timer and mutes");
 n=port_count;timer_at(1825,TIMER);
 check(port_count==n,"late timer after end-session ignored");
 reset();start_direct();ChimeProc(WIN,WM_CLOSE,0,0);
 check(!active && !live_timer && muted() && !window_alive &&
       destroy_calls==1 && quit_calls==1,"external close cleans up and exits");
 reset();start_direct();ChimeProc(WIN,WM_DESTROY,0,0);
 check(!active && !live_timer && muted() && quit_calls==1,
       "external destroy cleans up and posts quit");
 reset();now_tick=0xffffff80UL;start_direct();timer_at(0x25,TIMER);
 check(active && phase==1,"DWORD timer arithmetic survives wrap at first transition");
 timer_at(0xca,TIMER);check(active && phase==2,"DWORD wrap second transition");
 timer_at(0x20a,TIMER);check(active && phase==3,"DWORD wrap fade transition");
 timer_at(0x2b9,TIMER);check(!active && muted(),"DWORD wrap825-ms completion");
 reset();enqueue(1000,WM_TIMER,TIMER);enqueue(1165,WM_TIMER,TIMER);enqueue(1330,WM_TIMER,TIMER);
 enqueue(1650,WM_TIMER,TIMER);enqueue(1825,WM_TIMER,TIMER);
 result=WinMain(WIN,NULL,"",1);
 check(result==0 && !active && !live_timer && !window_alive && muted() &&
       quit_calls==1 && getmessage_calls==6 && dispatch_calls==5 &&
       translate_calls==5,"full WinMain message loop quits without resident window or timer");
 check(registered_class.style==0 && !registered_class.hCursor &&
       !registered_class.hIcon && !registered_class.hbrBackground,
       "hidden message window has no display resources");
 printf("PASS: %d assertions; host-only mocks of unchanged source.\n",check_count);
 return 0;
}
