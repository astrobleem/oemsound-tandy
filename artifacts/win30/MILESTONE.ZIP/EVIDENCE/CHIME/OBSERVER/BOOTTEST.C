#define WINVER 0x0300
#include <windows.h>
static HFILE log; static DWORD began; static int present;
static void record(char *label){
 char b[100]; HWND c=FindWindow("TandyStartupChime",NULL);
 HMODULE h=GetModuleHandle("TCHIME");
 wsprintf(b,"%s tick=%lu module=%u window=%u visible=%u\r\n",
  (LPSTR)label,GetTickCount(),(unsigned)h,(unsigned)c,
  c?(unsigned)IsWindowVisible(c):0);
 _lwrite(log,b,lstrlen(b));
}
LONG FAR PASCAL WndProc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_CREATE){log=_lcreat("C:\\BOOTTEST.LOG",0);record("START");
  began=GetTickCount();SetTimer(w,1,100,NULL);return 0;}
 if(m==WM_TIMER && GetTickCount()-began>=2000UL){
  present=GetModuleHandle("TCHIME")!=0;
  if(present && GetTickCount()-began<10000UL)return 0;
  record("END");_lwrite(log,present?"FAIL\r\n":"PASS\r\n",6);_lclose(log);
  KillTimer(w,1);DestroyWindow(w);return 0;}
 if(m==WM_DESTROY){PostQuitMessage(0);return 0;}
 return DefWindowProc(w,m,wp,lp);
}
int PASCAL WinMain(HINSTANCE h,HINSTANCE old,LPSTR cmd,int show){
 WNDCLASS c;MSG m;HWND w;
 c.style=0;c.lpfnWndProc=WndProc;c.cbClsExtra=0;c.cbWndExtra=0;c.hInstance=h;
 c.hIcon=0;c.hCursor=0;c.hbrBackground=0;c.lpszMenuName=0;c.lpszClassName="ChimeBootObserver";
 RegisterClass(&c);w=CreateWindow("ChimeBootObserver","Boot observer",0,0,0,0,0,0,0,h,0);
 while(GetMessage(&m,0,0,0)){TranslateMessage(&m);DispatchMessage(&m);}
 ExitWindows(0,0);return present;
}
